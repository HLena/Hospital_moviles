package com.example.hospital;



import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

import com.example.hospital.entidades.Hospital;

public class MainActivity extends AppCompatActivity {

    ImageButton b1,b2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        b1 = (ImageButton)findViewById(R.id.imgB1);


        b1.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(v.getContext(),HospitalsActivity.class);
                startActivityForResult(intent,0);
            }
        });

        ConexionSQLiteHelper conn=new ConexionSQLiteHelper(this,"db_hospital",null,1);





    }
}
