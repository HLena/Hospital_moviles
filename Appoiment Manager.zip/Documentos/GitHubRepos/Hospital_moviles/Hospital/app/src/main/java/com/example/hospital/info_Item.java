package com.example.hospital;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toolbar;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.example.hospital.utilidades.Utilidades;

import java.util.ArrayList;

public class info_Item extends AppCompatActivity {

    ListView listItemView;
    ListView listAppoimentsDoctor;

    ArrayList<String> listItemsValue = new ArrayList<String>();
    ArrayList<String> listItemsIds = new ArrayList<String>();

    Toolbar toolbar;

    String doctor_id;
    String doctor_name;
    String hospital_id;

    ConexionSQLiteHelper conn;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info__item);



        //toolbar = (Toolbar) findViewById(R.id.toolbar4);
        //toolbar.setLogo(R.drawable.cita_icon);


        listItemView = (ListView) findViewById(R.id.listViewitems);


        Bundle res= this.getIntent().getExtras();


        listItemsValue.clear();


        if(res!=null)
        {
            doctor_name=res.getString("doctor_name");
            doctor_id=res.getString("doctor_id");
            hospital_id=res.getString("hospital_id");
        }

        conn = new  ConexionSQLiteHelper(this.getApplicationContext(),"db_hospital",null,1);
        SQLiteDatabase db=conn.getReadableDatabase();

        String whereClause = "idMedico = ? and idHospital =?";
        String[] whereArgs = new String[] {
                doctor_id,
                hospital_id,
        };


        String[] campos = {Utilidades.CAMPO_ID_CITA,Utilidades.CAMPO_ID_PACIENTE_CITA,Utilidades.CAMPO_FECHA_CITA};

        Cursor cursor = db.query(Utilidades.TABLA_CITA,campos,whereClause,whereArgs,null,null,null);


        if (cursor.moveToFirst())
        {
            while (!cursor.isAfterLast()) {
                String fecha = cursor.getString(cursor.getColumnIndex("fecha"));
                String idAppoinment = cursor.getString(cursor.getColumnIndex("id"));

                listItemsIds.add(idAppoinment);
                listItemsValue.add("F: "+fecha+"  Cod: "+idAppoinment );

                cursor.moveToNext();
            }
        }


        listAppoimentsDoctor = (ListView)findViewById(R.id.listViewitems);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_2, android.R.id.text1, listItemsValue);
        listItemView.setAdapter(adapter);


    }
}
